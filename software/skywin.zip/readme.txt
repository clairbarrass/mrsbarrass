Greetings!  And welcome to SkyGlobe 2.0 for Windows.

This file and the SKYGLOBE.HLP help file are your best sources
for information about how to use the program.  The printed manual
was intended for the DOS version, so some of its information is
not applicable, but since the two programs were written by the
same person with the same vision in mind, you may find it useful
as well.

The SETUP.EXE included on the disk should be all you need to get up
and running in either Windows 3.1 or Windows 95.  You can use the
Add/Remove Programs facility in the latter to find the setup program
automatically, or run it as you would any other program via Run
or double-clicking from File Manager.  It will allow you to copy
the files anywhere you like and set up a group and an icon as usual.
An icon will be set up for the DOS program too, and you may wish to
change it after running setup by accessing the Properties feature,
to use the included .ICO file.  In Windows 95, the icons will be
placed in the KlassM group in the Programs section off the Start
button.  Just click to run, or in Windows 3.1, double-click on
the icon in the group window.  If you know you will never use the
DOS version, you can do with the files SG36.EXE, SKYGLOBE.DAT,
and README (not this README.TXT).  However, they are not all that
large, I suggest you keep them around to show and give copies to
your DOS-only friends.

Now on to actually using SkyGlobe for Windows!

In general, you click on the various edge toolbar elements to make
things happen, and right-click on those elements to reverse the action,
to adjust a setting for a corresponding toggle for the left-click, or in
some other way a related action takes place.  Left-clicking is often the
same as pressing a corresponding keystroke, and right-clicking is the
same as the shifted state of that keystroke.

In general, double-clicking on a toolbar element is the same as
Turbo-ing that element, whatever that element is, and
double-right-clicking is the same as Turbo-ing the shifted keystroke
corresponding to the toolbar element, if any.  (For those of you not
familiar with Turbo from earlier versions of SkyGlobe, it is a way to
continually feed commands into the program independent of AutoIncrement,
which only works for Time and Date.  Press Space and a key such as Z to
start continually Zooming in, click on the Turbo button and follow it up
with any repeatable command, or double-click on something as I just
described.  Home and End followed by a command are shortcuts to get
to a minimum or maximum setting.)

Now to some specifics:  Clicking on A will start Auto-Increment mode, as
will double-clicking on the top Time or Date buttons.  Clicking once on
one of those buttons will bump up the Time or Date by the currently set
increment, right-clicking will decrement.  There are several buttons for
pre-set Time and Date increments on the upper left, click or right-click
or double on any of them.  (More will appear as window size increases.)
H is for Hour, D is for Day, W is for Week, M is for Month, Y is for
Year, J is for Jump by a century, and U is for milleniUm.  All except
for W also allow you to use keystrokes or shifted keystrokes.

You can adjust Auto-Increment speed by clicking or right-clicking on the
<> icon.  It only works for the currently selected type of AutoIncrement
at any given time, which starts out as Time.  Right-click on the A, or
the Time or Date button while Auto-incrementing, to change direction,
and you can control Auto type by double-clicking on the Time or Date
buttons, or click on the other one while Auto is active for one.

You can click on the E button or press Enter to directly Enter a Time-
Date combination.  Click on the R to start Real Time, which synchronizes
the Time and Date to the system clock.  Right click on the R, and the
Time starts incrementing from the current time at a multiple of actual
time speed, instead of as fast as possible, as is usual in SkyGlobe. To
adjust this time speed multiple, you need to edit the RealSpeed entry in
a .CFG or .INI file, using 100=100% and adjusting for the desired speed.

The S button is for a Sidereal time increment (or decrement, with a
right-click).  Try double-clicking here when the ecliptic is visible to
watch the planets slide along it.  Ta is the same as the Tab key, and
bumps the time up to the next sunset.  Face west and double-click (or
double-right-click) to watch the Sun slide north and south between the
solstices, or to watch for a good apparation of Mercury.  T2, if your
window is large enough, does the same thing for sunrise.

The Lu and Ld are 'quick and dirty' estimated increments for Lunar month
and Lunar day, by which I mean the approximate time from one day to the
next when the moon will be at a similar azimuth.

There are several ways to change directions:  The arrow buttons are the
most obvious.  You can right-click or double-click on them and they will
act as you expect.  Click on the direction bar or the elevation bar to
instantly change the direction or elevation to a value corresponding to
the spot you click.  Right-click on one of them, and you will move one
degree either left or right or up or down.  Double-click for Turbo.

Click anywhere in the sky view to re-center at that spot.  The little
inset circle above the elevation bar controls the Overview feature,
which also allows you to re-center from within it.  Click to turn on the
Overview, which will come on and go off at a set Zoom, and right-click
to set that Zoom threshold at the current Zoom level.  You can also
click on the RA-Dec button to use a menu to re-center at a given RA and
Dec, or the Direction or Elevation buttons to get to that menu.  You
can Lock the view center at a certain RA-Dec by double-right-clicking
on a spot, and unLock by pressing Esc.  This is handy when used in
conjunction with various Auto features.

Click on the planet buttons to quickly re-center on the planet, or
right-click to display images for it.  The Moon is the top button (it
will display phase in the next version), the Sun is next, then the
planets are in order, but which ones are displayed depends on how large
your window is.

Now is a good time to mention that you can have .LST files for images,
which are simple ASCII files containing filenames of images.  You can
also have up to three image directories in SKYGLOBE.INI, which can be
adjusted and saved via the File/Directories menu entry.  If you copied
all the files from the root directory of the CD to your hard drive and
properly set up the directories, you may enjoy sitting back and watching
the several pre-packaged .LST files, for various planets and other
groupings.  (If you don't have the CD, don't worry about it, but you
can still create .LST files pointing to any images you have from other
sources.) If there is no CD of any kind in the drive, you may get a
system message telling you SkyGlobe couldn't find a data file.  To avoid
this message, either use the File/Directories command to set the data
directory and image directories to point to your hard drive instead
of the CD, or simply make sure the CD drive has something in it, even
if it's not the SkyGlobe CD.  You can use File/Directories to set Image
Delay times between files up to 65 seconds via the File/Directories
command--I like 0 seconds for .LST files, but then again single files
tend to go by pretty quickly that way.

While viewing image sequences, click on the image to freeze it, double-
click to go right to the next in sequence, right-click to go back one,
and double-right-click or hit Esc to get out.  It sometimes helps to
click first to freeze and then right or double-right click.  And, don't
forget you can right-click on planets and Messiers to display any images
available for them, in addition to browsing around via the menu.

I offer SGIMAGE as a freeware general-purpose image viewer, even though
it is specially designed for use with SkyGlobe 2.0 for Windows.  You
can drag-and-drop image files on it, Run it with a command line argument
in File Manager or Program Manager, or Associate it with various image
file extensions.


We are sort of travelling counter-clockwise from the upper left in this
description, and next is the RA-Dec bar, which also displays Alt-Az
information.  There are various Az conventions; in SkyGlobe you can select
between North=0 and South=0 via the Toggles menu.  The next button shows
either the current object under the cursor or the constellation containing
the cursor.  After the down arrow we find buttons for Turbo, Home, and End.
After passing by the direction and elevation bars (which are described
above) and one more arrow, we find several toggles for various display
features.

In general here, click to turn on the associated feature, and right-click
to adjust it in some way. They can all be saved with configurations once
you find combinations you like, (use SKYGLOBE.INI as the file name if you
want this to be the default).

In particular, the circle within circle for the Overview is toggled with
a click and the threshold for automatic activation is set with a right-
click.  There are no settings for the Radiant button, but it is toggled
as you would expect.  If your window size is large enough to see Guidelines
and Milky Way, you can toggle them with a left, and choose between lines
and regions with a right.  The Ground Horizon and Local Horizon buttons
work the same way.

Constellation labels are toggled, or you can select from abbreviations
or names and two font sizes.  Right-clicking on the Star Label button
rolls through more and more names until you go back to the lowest level.
Right-clicking on the Messier button rolls through combinations of labels
and Messier or Messier and NGC.  The choice for planets is the bird's
eye view.

RA-Dec lines normally turn on more and more as you zoom in (try it!), but
right-clicking will force selection of a particular number of lines.
Constellation lines are toggled or you can select how many to display.

Most of the above buttons have keyboard analogs, which are shifted for
the right click behavior:  O for Overview, G for Guidelines, K for milKy
way, F5 for Ground Horizon, F9 for Con Labels, F8 for Star Labels, F7
for RA-Dec, F4 for Messier, and F3 for Planets.  C affects constellations,
F6 toggles Ecliptic, and F11 and F12 roll through multiple LocalHors, if
any, while Shift-F11 and Shift-F12 both toggle LocalHor type between
lines and regions.

Finally, the top right button is new; click on it to quickly toggle
between 'normal' and star-only views.  Right-clicking on this one is
the same as the B key, and it rolls through four different brightness
levels.  Shift-B goes back (no mouse analog for this one).

Long and lat buttons are self-explanatory (you can also use PgUp and PgDn
to adjust latitude, which works well with Turbo to learn how latitude
affects sky view), then we find the Location button, also pretty easy
(and which also works interestingly with Turbo).  The menu and the L
key are other ways to adjust Location.  Next is Zoom, which now shows
approximate field of view in degrees if the window is large enough.
Note that changing zoom affects number of stars displayed automatically,
which brings us to the next button past the arrow.  This button both
shows and controls number of stars to display (if there isn't enough
room, I use the suffix "k" to mean 1000), and the + and - keys do the
job if you don't like the mouse or if the toolbars aren't visible (see
and try F2 and Shift-F2).

Some last keys and clicks before we get to the menu items:  You can
right-click on the E button (or the upper left corner of the sky display
if it isn't visible) to simulate the F2 key, which toggles the toolbar
display.  Shift-F2 rolls through combinations of toolbars and font sizes,
Shift-F1 toggles the menu display.  You can save these choices within
configurations.

Okay, it's menu time.  The Help entry can also be accessed via F1.  The
Toggles entry has a miscellany of settings I couldn't get at with right
clicks or keystrokes.  Normally at high zooms and large variances from
epoch 2000.0, the RA-Dec lines are 'shadowed' with their 2000.0 counter-
parts; you can turn this off if you like, but try Turbo-Y to see it at
work first.

I normally display Azimuth down in the lower left RA-Dec bar with North
defined as 0, but you can change this to South=0 in Toggles (it's always
clockwise in SkyGlobe).

Normally I bias the center of the screen to keep as much sky area as
possible visible when the view center is near or below the horizon; you
can turn this biasing off.  Also, if you have a LocalHorizon that is
pretty high all the way around, you may want to turn on LHBias, which
'slides' the center even more when appropriate.

Labels such as Horizon Letters or Star Labels, etc., can be either
transparent or opaque.

If you like to have images sequencing in the background, while still
playing around in SkyGlobe, you may want to have AlwaysRefresh checked.
It slows things down just a bit, but it keeps the SkyGlobe palette
looking good even while various-colored planets are flickering by.  By
the way, now is a good time to suggest you try displaying a big .LST
file, then click on the SkyGlobe and SGImage title bars to switch
between the two.  You can re-size and re-position them to your heart's
content; don't forget that a single click will freeze the image, and
you need to double-click to start sequencing again.

Outlines for the Large and Small Magellanic Clouds are normally displayed
whenever the Milky Way is turned on, but you can turn them off if you
prefer.

Search will enable you to find and re-center on stars, Messiers, NGCs,
Constellation centers, and Planets.

The Images menu allows you to choose individual image files or .LST
file collections.  Remember to set Image Directories properly, and
to use the type control as needed.  I have settled on .PCX files as
my lingua franca for the time being.  And don't forget, you can right-
click on planet buttons or objects in the sky view to display images
for them.

The Location menu entry gives you a list box of SkyGlobe's built-in
locations, or you can replace the very first location with the Custom
menu entry.  Please use the indicated format for lat-long, a number
that looks like a decimal, but the digits on the right are really
minutes, not fractional degrees.

The File menu is where you Save and Load configurations, to set the
Directories for the .DT0-.DT9 files (if you had the CD) that aren't
in the SKYGLOBE.EXE directory, to print, and to load and save single
LocalHor files.

The configuration files are in the normal Windows .INI file format, and
will normally be named with .CFG or .INI extensions.  Use SKYGLOBE.INI
for the default configuration.  You will be given a choice to save the
Time and Date with a configuration or not, since you may wish to save
Zooms, Directions, etc., but have the program come up with the current
Time and Date when it is started.  These ASCII files can be edited with
Notepad or some other editor if you like (and that's currently the only
way to adjust RealSpeed for right-clicking on R, default 10x normal speed
since it's listed in percentages, and to adjust the speed of Real Time
updates, in milliseconds, default every 5 seconds).

Printing is much better than in the previous Windows version, just press
P or use the menu, and I suggest you use Print Manager;Options;Printer
Setup to select printers and choose landscape before you start SkyGlobe.
The program adjusts for non-1 to 1 aspect ratios, but you may find it
works best if you select a 1 to 1 ratio if you can.  The printouts look
pretty nice in color too!

Pressing PrintScreen or Alt-PrintScreen from within any Windows program
copies the current window or screen to the clipboard, and you can then
use Paste in a program such as Paintbrush or Hijaak to create image file
screen-shots of your SkyGlobe screens.

Single Local Horizon files can be saved and loaded via the menu.  These
are ASCII files of 360 lines each, starting with due North as the first
line, and the values are integer degrees.  If you want to bring in old
Local Horizon files, it's probably best to save them using the old
program, rename them so you can save more than one (since you can only
use the name LOCALHOR.TXT in the first Windows version), then bring them
to the new program via the menu.  I now have a 'default' Local Horizon
of two degrees all the way for every location, and you can edit any
current Local Horizon by pressing Insert, then using the cursor keys to
raise or lower values.  Press Insert again or Enter to keep your changes;
Esc to lose them.  If you have made LocalHor changes during a program
run, you will be prompted on program exit to see if you want to save the
current LocalHor state.  This will create a file that will be loaded at
program launch from now on; if you decide you don't want it any more,
simply delete or rename SKYGLOBE.LH.  Again, you can save a single
LocalHor and then bring it in later if an .LH file gets cluttered and
you need to start over.


Well, that's how to use SkyGlobe 2.0 for Windows.  I hope you enjoy the
program!

Peace and Clear Skies,

Sincerely,
Mark A Haney
KlassM Software
