Timer Parameters

Each parameter must be separated by a space but can occur in any order

d:    Description Text - must follow immediately after the d:
No spaces permitted
e.g.  d:BlotBaking

t:hh:mm:ss  Elapse Time for Timer - must follow immediatly after the t:
Must include full hh:mm:ss
e.g.  t:00:05:00

m:   AutoMinimise 

s:   AutoStart - must be used with AutoMinimise

x:   Minimise on Start

a:   Alarm Sound Select - must be in range 1 - 6
e.g. a:3

l:   Use Landscape Format

r:   Auto-Restart